import sqlite3

conn = sqlite3.connect('decorlux.db')
c = conn.cursor()

# Таблица клиентов
c.execute('''CREATE TABLE IF NOT EXISTS clients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT,
    address TEXT
)''')

# Таблица заказов
c.execute('''CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER NOT NULL,
    order_date TEXT NOT NULL,
    product_name TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    price REAL NOT NULL,
    status TEXT DEFAULT 'новый',
    FOREIGN KEY (client_id) REFERENCES clients(id)
)''')

# Добавим тестовые данные
c.execute("INSERT INTO clients (full_name, phone) VALUES ('Иванов Иван', '+79991234567')")
c.execute("INSERT INTO clients (full_name, phone) VALUES ('Петрова Анна', '+79123456789')")

c.execute("INSERT INTO orders (client_id, order_date, product_name, quantity, price, status) VALUES (1, '2026-05-15', 'Штора блэкаут', 2, 3500, 'новый')")
c.execute("INSERT INTO orders (client_id, order_date, product_name, quantity, price, status) VALUES (2, '2026-05-16', 'Рулонная штора', 3, 2800, 'выполнен')")

conn.commit()
conn.close()

print("База данных создана! Файл: decorlux.db")