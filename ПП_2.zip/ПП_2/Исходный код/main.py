import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from datetime import datetime

DB_NAME = 'decorlux.db'

def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS clients (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        full_name TEXT NOT NULL,
        phone TEXT NOT NULL,
        email TEXT,
        address TEXT)''')
    c.execute('''CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        client_id INTEGER,
        order_date TEXT,
        product_name TEXT,
        quantity INTEGER,
        price REAL,
        status TEXT,
        FOREIGN KEY (client_id) REFERENCES clients(id))''')
    conn.commit()
    conn.close()

class App:
    def __init__(self, root):
        self.root = root
        root.title('Декора-Люкс-1 - Учёт заказов')
        root.geometry('950x600')
        self.create_widgets()
        self.load_clients()
        self.load_orders()
    
    def create_widgets(self):
        notebook = ttk.Notebook(self.root)
        notebook.pack(fill='both', expand=True)
        
        # Вкладка Клиенты
        self.clients_frame = ttk.Frame(notebook)
        notebook.add(self.clients_frame, text='Клиенты')
        self.build_clients_tab()
        
        # Вкладка Заказы
        self.orders_frame = ttk.Frame(notebook)
        notebook.add(self.orders_frame, text='Заказы')
        self.build_orders_tab()
    
    def build_clients_tab(self):
        # Форма ввода
        ttk.Label(self.clients_frame, text='ФИО:').grid(row=0, column=0, padx=5, pady=5)
        self.client_name = tk.Entry(self.clients_frame, width=30)
        self.client_name.grid(row=0, column=1, padx=5, pady=5)
        
        ttk.Label(self.clients_frame, text='Телефон:').grid(row=1, column=0, padx=5, pady=5)
        self.client_phone = tk.Entry(self.clients_frame, width=30)
        self.client_phone.grid(row=1, column=1, padx=5, pady=5)
        
        ttk.Label(self.clients_frame, text='Email:').grid(row=2, column=0, padx=5, pady=5)
        self.client_email = tk.Entry(self.clients_frame, width=30)
        self.client_email.grid(row=2, column=1, padx=5, pady=5)
        
        ttk.Button(self.clients_frame, text='Добавить клиента', command=self.add_client).grid(row=3, column=0, padx=5, pady=10)
        ttk.Button(self.clients_frame, text='Удалить клиента', command=self.del_client).grid(row=3, column=1, padx=5, pady=10)
        
        # Таблица клиентов
        columns = ('id', 'ФИО', 'Телефон', 'Email')
        self.clients_tree = ttk.Treeview(self.clients_frame, columns=columns, show='headings', height=15)
        for col in columns:
            self.clients_tree.heading(col, text=col)
            self.clients_tree.column(col, width=150)
        self.clients_tree.grid(row=4, column=0, columnspan=2, padx=10, pady=10)
    
    def build_orders_tab(self):
        # Форма ввода
        ttk.Label(self.orders_frame, text='Клиент:').grid(row=0, column=0, padx=5, pady=5)
        self.order_client = ttk.Combobox(self.orders_frame, width=40)
        self.order_client.grid(row=0, column=1, padx=5, pady=5)
        
        ttk.Label(self.orders_frame, text='Товар:').grid(row=1, column=0, padx=5, pady=5)
        self.order_product = tk.Entry(self.orders_frame, width=30)
        self.order_product.grid(row=1, column=1, padx=5, pady=5)
        
        ttk.Label(self.orders_frame, text='Количество:').grid(row=2, column=0, padx=5, pady=5)
        self.order_qty = tk.Entry(self.orders_frame, width=10)
        self.order_qty.grid(row=2, column=1, padx=5, pady=5, sticky='w')
        
        ttk.Label(self.orders_frame, text='Цена:').grid(row=3, column=0, padx=5, pady=5)
        self.order_price = tk.Entry(self.orders_frame, width=10)
        self.order_price.grid(row=3, column=1, padx=5, pady=5, sticky='w')
        
        ttk.Button(self.orders_frame, text='Добавить заказ', command=self.add_order).grid(row=4, column=0, padx=5, pady=10)
        ttk.Button(self.orders_frame, text='Изменить статус', command=self.update_status).grid(row=4, column=1, padx=5, pady=10)
        
        # Таблица заказов
        columns = ('ID', 'Клиент', 'Товар', 'Кол-во', 'Цена', 'Статус')
        self.orders_tree = ttk.Treeview(self.orders_frame, columns=columns, show='headings', height=15)
        for col in columns:
            self.orders_tree.heading(col, text=col)
            self.orders_tree.column(col, width=130)
        self.orders_tree.grid(row=5, column=0, columnspan=2, padx=10, pady=10)
    
    def load_clients(self):
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute('SELECT id, full_name, phone, email FROM clients')
        # Очистить таблицу
        for row in self.clients_tree.get_children():
            self.clients_tree.delete(row)
        # Заполнить
        for row in c.fetchall():
            self.clients_tree.insert('', 'end', values=row)
        # Обновить выпадающий список клиентов
        c.execute('SELECT id, full_name FROM clients')
        self.order_client['values'] = [f"{r[0]} - {r[1]}" for r in c.fetchall()]
        conn.close()
    
    def load_orders(self):
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute('''SELECT orders.id, clients.full_name, orders.product_name, 
                            orders.quantity, orders.price, orders.status
                     FROM orders JOIN clients ON orders.client_id = clients.id''')
        for row in self.orders_tree.get_children():
            self.orders_tree.delete(row)
        for row in c.fetchall():
            self.orders_tree.insert('', 'end', values=row)
        conn.close()
    
    def add_client(self):
        name = self.client_name.get().strip()
        phone = self.client_phone.get().strip()
        email = self.client_email.get().strip()
        
        if not name or not phone:
            messagebox.showerror('Ошибка', 'Заполните ФИО и телефон')
            return
        
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute('INSERT INTO clients (full_name, phone, email) VALUES (?, ?, ?)',
                  (name, phone, email))
        conn.commit()
        conn.close()
        self.load_clients()
        self.client_name.delete(0, tk.END)
        self.client_phone.delete(0, tk.END)
        self.client_email.delete(0, tk.END)
        messagebox.showinfo('Успех', 'Клиент добавлен')
    
    def del_client(self):
        sel = self.clients_tree.selection()
        if not sel:
            messagebox.showerror('Ошибка', 'Выберите клиента')
            return
        id = self.clients_tree.item(sel[0])['values'][0]
        if messagebox.askyesno('Подтверждение', 'Удалить клиента и все его заказы?'):
            conn = sqlite3.connect(DB_NAME)
            c = conn.cursor()
            c.execute('DELETE FROM orders WHERE client_id=?', (id,))
            c.execute('DELETE FROM clients WHERE id=?', (id,))
            conn.commit()
            conn.close()
            self.load_clients()
            self.load_orders()
    
    def add_order(self):
        if not self.order_client.get():
            messagebox.showerror('Ошибка', 'Выберите клиента')
            return
        client_id = int(self.order_client.get().split(' - ')[0])
        product = self.order_product.get().strip()
        qty = self.order_qty.get().strip()
        price = self.order_price.get().strip()
        
        if not product or not qty or not price:
            messagebox.showerror('Ошибка', 'Заполните все поля')
            return
        
        try:
            qty = int(qty)
            price = float(price)
        except ValueError:
            messagebox.showerror('Ошибка', 'Количество и цена должны быть числами')
            return
        
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute('''INSERT INTO orders (client_id, order_date, product_name, quantity, price, status)
                     VALUES (?, ?, ?, ?, ?, ?)''',
                  (client_id, datetime.now().strftime('%Y-%m-%d'), product, qty, price, 'новый'))
        conn.commit()
        conn.close()
        self.load_orders()
        self.order_product.delete(0, tk.END)
        self.order_qty.delete(0, tk.END)
        self.order_price.delete(0, tk.END)
        messagebox.showinfo('Успех', 'Заказ добавлен')
    
    def update_status(self):
        sel = self.orders_tree.selection()
        if not sel:
            messagebox.showerror('Ошибка', 'Выберите заказ')
            return
        order_id = self.orders_tree.item(sel[0])['values'][0]
        new_status = simpledialog.askstring('Статус', 'Введите статус (новый/выполнен/отменён)')
        if new_status in ['новый', 'выполнен', 'отменён']:
            conn = sqlite3.connect(DB_NAME)
            c = conn.cursor()
            c.execute('UPDATE orders SET status=? WHERE id=?', (new_status, order_id))
            conn.commit()
            conn.close()
            self.load_orders()
            messagebox.showinfo('Успех', 'Статус обновлён')
        else:
            messagebox.showerror('Ошибка', 'Неверный статус. Используйте: новый, выполнен, отменён')

if __name__ == '__main__':
    init_db()
    root = tk.Tk()
    app = App(root)
    root.mainloop()