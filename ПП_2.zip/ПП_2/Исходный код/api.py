from flask import Flask, jsonify, request
import sqlite3

app = Flask(__name__)

def get_db():
    conn = sqlite3.connect('decorlux.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/api/orders')
def get_orders():
    conn = get_db()
    orders = conn.execute('SELECT * FROM orders').fetchall()
    return jsonify([dict(order) for order in orders])

@app.route('/api/clients')
def get_clients():
    conn = get_db()
    clients = conn.execute('SELECT id, full_name, phone FROM clients').fetchall()
    return jsonify([dict(client) for client in clients])

@app.route('/api/order/<int:id>', methods=['PUT'])
def update_order(id):
    data = request.json
    conn = get_db()
    conn.execute('UPDATE orders SET status=? WHERE id=?', (data['status'], id))
    conn.commit()
    return jsonify({'success': True, 'message': 'Статус обновлён'})

@app.route('/api/order', methods=['POST'])
def create_order():
    data = request.json
    conn = get_db()
    conn.execute('''INSERT INTO orders (client_id, order_date, product_name, quantity, price, status)
                    VALUES (?, date('now'), ?, ?, ?, ?)''',
                 (data['client_id'], data['product_name'], data['quantity'], data['price'], 'новый'))
    conn.commit()
    return jsonify({'success': True, 'message': 'Заказ добавлен'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)